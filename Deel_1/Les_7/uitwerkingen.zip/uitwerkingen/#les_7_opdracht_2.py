#les_7_opdracht_2

zin = "ik ben hard op weg om developer worden"

for _ in range(20):
    print(zin)