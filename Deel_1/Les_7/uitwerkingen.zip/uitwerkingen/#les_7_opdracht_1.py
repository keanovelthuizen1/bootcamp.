#les_7_opdracht_1


for i in range(1, 26):
    print(i)