#les7_opdracht_4
i= 625
count = 0
while i >=12:
    i-=12
    count+=1

print (f"12 past {count} in 625")