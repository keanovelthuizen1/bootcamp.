#les7_opdracht_3
i= 625
count = 0
while i >=25:
    i-=25
    count+=1

print (f"25 past {count} in 625")