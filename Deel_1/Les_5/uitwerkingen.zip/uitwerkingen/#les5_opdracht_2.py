#les5_opdracht_2

print(3*"hallo")

#je vertelt aan python dat je hallo 3 keer wil printen