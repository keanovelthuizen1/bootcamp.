#les5_opdracht_4
import math

straal = float (input("voer de straal van de cirkel in "))

oppervlakte = (math.pi*straal**2)

print(f"De oppervlakte van een cirkel met een straal van {straal} is {oppervlakte}")

