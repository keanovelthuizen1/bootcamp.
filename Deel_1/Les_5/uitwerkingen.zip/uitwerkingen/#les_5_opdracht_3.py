#les_5_opdracht_3



var1 = float (input("wat is nummer 1? " )) # wordt van de user gevraagt om nummer 1 in te voeren
var2 = float (input("wat is nummer 2? " )) # wordt van de user gevraagt om nummer 2 in te voeren
var3 = float (input("wat is nummer 3? " )) # wordt van de user gevraagt om nummer 3 in te voeren

vargemiddeld = (var1+var2+var3)/3 # gemiddelde is alles opgetelt gedeeld door het totaal aantal nummers

print(f"het gemiddelde is {vargemiddeld}") 