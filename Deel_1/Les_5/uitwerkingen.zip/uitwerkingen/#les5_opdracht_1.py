#les5_opdracht_1

naam = "252"
print("Hallo " + naam + ",ik leer nu programmeren.")

# ik heb van 252 een str gemaakt inplaats van een int door het in dubble quotes te zetten