#les_9_opdracht_1


a=5
b=3
c=2
if (a==6 and b==4 or c==2): # bij deze is de conditie waar als a en b de juiste getal zijn of als c 2 is
   print("De conditie is waar")
else: 
   print("De conditie is niet waar")


a=5
b=3
c=2
if (a==6 and (b==4 or c==2)): #bij deze is de conditie alleen waar als elke variable het juiste getal heeft
   print("De conditie is waar")
else:
   print("De conditie is niet waar")

