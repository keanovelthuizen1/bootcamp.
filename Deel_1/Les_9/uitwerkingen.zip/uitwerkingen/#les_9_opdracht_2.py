#les_9_opdracht_2
getal = int(input("Voer getal in: "))

if getal % 7 == 0 and getal % 11 == 0.2:
    print("getal is zonder rest deelbaar door 7 en 11")
else:
    print("getal is niet zonder rest deelbaar door 7 en 11")
x