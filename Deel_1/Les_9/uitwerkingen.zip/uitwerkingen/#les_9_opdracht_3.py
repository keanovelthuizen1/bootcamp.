#les_9_opdracht_3

leeftijd = 18
snor = 'j' 
diploma = 'j'  

if (leeftijd >= 18 and snor == 'j') or (leeftijd < 18 and diploma == 'j'):
    print("Gefeliciteerd, je bent aangenomen!")
else:
    print("Sorry, je voldoet niet aan de vereisten voor de baan.")
