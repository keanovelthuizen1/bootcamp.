#les6_opdracht_3

leeftijd = float (input("Wat is jouw leeftijd?"))

if leeftijd < 16:
    print("jammer je zal nog even moeten wachten")

if leeftijd > 16:
    print("Gefeliciteerd je mag je scooterrijbewijs halen")

if leeftijd == 16:
    print("Gefeliciteerd je mag je scooterrijbewijs halen.")