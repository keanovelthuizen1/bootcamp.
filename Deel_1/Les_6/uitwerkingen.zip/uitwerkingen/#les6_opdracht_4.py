#les6_opdracht_4

a = 3
b = 5
print(a < b)  # Dit zal True afdrukken, want 3 is kleiner dan 5

x = 10
y = 7
print(x > y)  # Dit zal True afdrukken, want 10 is groter dan 7

m = 5
n = 5
print(m == n)  # Dit zal True afdrukken, want 5 is gelijk aan 5

p = 4
q = 6
print(p != q)  # Dit zal True afdrukken, want 4 is niet gelijk aan 6

e = 8
f = 8
print(e <= f)  # Dit zal True afdrukken, want 8 is minder dan of gelijk aan 8

g = 12
h = 10
print(g >= h)  # Dit zal True afdrukken, want 12 is groter dan of gelijk aan 10
