#les6_opdracht_1
x = 18 # als deze waard geen 18 is dan wordt de print opdracht niet uitgevoerd
if x == 18: # er stond origineel maar 1 = teken maar het moet 2 zijn want 2 = tekens zijn een vergelijking
    print('de waarde van x = 18')
