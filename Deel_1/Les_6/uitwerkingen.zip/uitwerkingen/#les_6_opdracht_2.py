#les_6_opdracht_2

a = float (input(f"wat is de waarde van A?" ))
b = float (input(f'wat is de waarde van b?' ))


if (a > b):
    print("variable a is groter dan b")
    
if (a < b):
    print("variable b is groter dan a")

if (a == b):
    print("variable a is net zo groot als b")


