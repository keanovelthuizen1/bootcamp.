#les_4_opdracht_8

totaal = 625
deelbaar = 13

aantal_keer = totaal//deelbaar
overblijf = totaal%deelbaar 

print(f"{deelbaar} past {aantal_keer} in {totaal} ")
print(f"er blijft {overblijf} over")

