#les_4_opdracht_3

naam = "Keano"
print("Hallo " + naam + ",ik leer nu programmeren.")

naam2 = "Colin"
print("Hallo " + naam2 + ",leer jij nu ook programmeren?")