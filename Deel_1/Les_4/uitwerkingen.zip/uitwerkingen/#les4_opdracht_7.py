#les4_opdracht_7

print( (431 / 100 * 100) )
# verwachte resulataat: 431
# Dit gebeurt omdat we 431 delen door 100 (0,01), en dan vermenigvuldigen we met 100 om het resultaat weer terug te krijgen.