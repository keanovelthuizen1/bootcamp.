#les4_opdracht_4

naam = 252
print("Hallo " + naam + ",ik leer nu programmeren.")

# De variabele 'naam' is nu van het type integer (int).

