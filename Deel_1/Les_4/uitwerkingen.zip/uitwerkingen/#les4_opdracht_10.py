#les4_opdracht_10

seconden_per_minuut = 60
minuut_per_uur = 60
uur_per_dag = 24
dag_per_week = 7
dag_per_jaar = 365

seconden_per_dag = (seconden_per_minuut*minuut_per_uur*uur_per_dag)
seconden_per_week = (seconden_per_dag*dag_per_week)
seconden_per_jaar = (seconden_per_dag*dag_per_jaar)

print(f"aantal seconden in een dag is {seconden_per_dag}")
print(f"aantal seconden in een week is {seconden_per_week}")
print(f"aantal seconden in een jaar is {seconden_per_jaar}")