#les4_opdracht_1


print(15+4)     # Optellen: 19
print(15-4)     # Aftrekken: 11
print(15*4)     # Vermenigvuldigen: 60
print(15/4)     # Delen (met decimalen): 3.75
print(15//4)    # Delen (gehele getallen): 3
print(15**4)    # Machtsverheffen: 50625
print(15%4)     # Modulus (rest na deling): 3
