#les4_opdracht_2

print(5 * 2 - 3 + 4 / 2)     # Eerst vermenigvuldigen en delen, dan optellen en aftrekken: 8.0
print(5 * 2 - 3 + 4 / 2)     # Eerst vermenigvuldigen, dan delen, dan optellen en aftrekken: 9.0

print( (5*2) - (3+4) /2 )
print( ((5*2) -(3+4)) / 2 )