#les4_opdracht_5

variable_een = 25
variable_twee = 0

resultaat = variable_een/variable_twee

print(resultaat)