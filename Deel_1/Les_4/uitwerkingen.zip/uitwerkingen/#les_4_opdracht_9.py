#les_4_opdracht_9

studenten = 25
collegegeld = 1115

uitkomst = (studenten*collegegeld) 

print(uitkomst)