#les12_opdracht_1

name = input("wat is je naam? ")
print(f"Hallo {name}")

leeftijd = int(input("wat is je leeftijd? "))


print(f"over 5 jaar ben je {leeftijd + 5}")