#les12_opdracht_2

getal1 = float(input("wat is getal nummer 1? " ))
getal2 = float(input("wat is getal nummer 2 " ))

gemiddelde = getal1 + getal2 / 2

print(gemiddelde)
